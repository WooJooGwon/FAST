﻿//----------------------------------------------------------------------------
//  Copyright (C) 2004-2018 by EMGU Corporation. All rights reserved.       
//----------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Features2D;
using Emgu.CV.Flann;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Emgu.CV.XFeatures2D; //BriefDescriptorExtractor



namespace FeatureMatchingExample
{
    public static class DrawMatches
    {
        public static void FindMatch(Mat modelImage, Mat observedImage, out long matchTime, out VectorOfKeyPoint modelKeyPoints, out VectorOfKeyPoint observedKeyPoints, VectorOfVectorOfDMatch matches)
        {

            Stopwatch watch;
           

            modelKeyPoints = new VectorOfKeyPoint();
            observedKeyPoints = new VectorOfKeyPoint();

            using (UMat uModelImage = modelImage.GetUMat(AccessType.Read))
            using (UMat uObservedImage = observedImage.GetUMat(AccessType.Read))
            {
                KAZE featureDetector = new KAZE();

                //extract features from the object image
                Mat modelDescriptors = new Mat();
                featureDetector.DetectAndCompute(uModelImage, null, modelKeyPoints, modelDescriptors, false);

                watch = Stopwatch.StartNew();

                // extract features from the observed image
                Mat observedDescriptors = new Mat();
                featureDetector.DetectAndCompute(uObservedImage, null, observedKeyPoints, observedDescriptors, false);
                watch.Stop();

            }
            matchTime = watch.ElapsedMilliseconds;
        }



        /// <summary>
        /// Draw the model image and observed image, the matched features and homography projection.
        /// </summary>
        /// <param name="modelImage">The model image</param>
        /// <param name="observedImage">The observed image</param>
        /// <param name="matchTime">The output total time for computing the homography matrix.</param>
        /// <returns>The model image and observed image, the matched features and homography projection.</returns>

        //Harris Corner Detection코너검출할때 대표적인 친구.
        public static Mat Draw(Mat modelImage, Mat observedImage, out long matchTime)
        {
            FastDetector fastCPU = new FastDetector(10, true);
            //10 => 중심 픽셀의 강도와이 픽셀 주변의 원의 픽셀 사이의 차이에 대한 임계 값입니다.
            //true => nonmaxSupression 그것이 참이면 검출되지 않은 코너 (키포인트)에 최대가 아닌 울림이 적용됩니다.
            //https://m.blog.naver.com/PostView.nhn?blogId=tlaja&logNo=220996212245&proxyReferer=https%3A%2F%2Fwww.google.com%2F
            //https://pdfs.semanticscholar.org/cd26/7a4b04d835dbecf01d47fc69ed3a38c23055.pdf <-논문자료
            VectorOfKeyPoint modelKeyPoints = new VectorOfKeyPoint();
            VectorOfKeyPoint observedKeyPoints = new VectorOfKeyPoint(); //입력 및 목표영상 특징점 변수
            BriefDescriptorExtractor descriptor = new BriefDescriptorExtractor();
            VectorOfVectorOfDMatch matches = new VectorOfVectorOfDMatch();

            Mat mask = null;  //대응점 저장 

            //extract features from the object image
            fastCPU.DetectRaw(modelImage, modelKeyPoints);
            //특징점을 탐색.
            Mat modelDescriptors = new Mat();
            descriptor.Compute(modelImage, modelKeyPoints, modelDescriptors);
            //입력된 이미지를 계산함  이미지, 계산방식, 출력
            FindMatch(modelImage, observedImage, out matchTime, out modelKeyPoints, out observedKeyPoints, matches);
            // extract features from the observed image
            fastCPU.DetectRaw(observedImage, observedKeyPoints);
            Mat observedDescriptors = new Mat();
            descriptor.Compute(observedImage, observedKeyPoints, observedDescriptors);
            
            Mat result = new Mat();
            Features2DToolbox.DrawMatches(modelImage, modelKeyPoints, observedImage, observedKeyPoints,
               matches, result, new MCvScalar(255, 0, 0), new MCvScalar(255, 0, 0), mask);

            return result;

        }


    }
}
