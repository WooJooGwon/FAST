using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("3.4.1.2976")]
[assembly: AssemblyFileVersion("3.4.1.2976")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Emgu Corporation")]
[assembly: AssemblyProduct("Emgu.CV")]
[assembly: AssemblyCopyright("Copyright Emgu Corporation 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
